import Header from './header'
import Footer from './footer.js';
import Body from './body';
function JSX(){
    return(
        <div>
            <Header></Header>
            <Footer></Footer>
            <Body></Body>
            
        </div>
    );

}
export default JSX;