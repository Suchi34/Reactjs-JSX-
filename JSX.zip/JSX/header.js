function Header(){
    const header =<h1>hello world</h1>;
    
    return(
        <div>
            {header}
          
        </div>
    );

}
export default Header;