function Body(){
    const body =<h1>JSX allow us to write html inside Javascript</h1>;
    
    return(
        <div >
            {body}
          
        </div>
    );

}
export default Body;