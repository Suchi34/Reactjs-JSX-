function Footer(){
    const footer =<h1>JSX</h1>;
    
    return(
        <div >
            {footer}
          
        </div>
    );

}
export default Footer;